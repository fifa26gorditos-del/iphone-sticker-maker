import SwiftUI

@main
struct StickerMakerApp: App {
    var body: some Scene { WindowGroup { RootView() } }
}

struct RootView: View {
    @State private var rev = 0
    var body: some View {
        TabView {
            CreateView(rev: $rev).tabItem { Label("Crear", systemImage: "wand.and.stars") }
            LibraryView(rev: $rev).tabItem { Label("Mis stickers", systemImage: "square.grid.2x2") }
        }
    }
}
