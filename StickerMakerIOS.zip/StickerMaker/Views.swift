import SwiftUI
import PhotosUI
import SDWebImage
import SDWebImageWebPCoder

struct CreateView: View {
    @Binding var rev: Int
    @State private var item: PhotosPickerItem?
    @State private var src: Source?
    @State private var zoom: CGFloat = 1
    @State private var rot: Double = 0
    @State private var ox: CGFloat = 0
    @State private var oy: CGFloat = 0
    @State private var text = ""
    @State private var res = 512
    @State private var crop = false
    @State private var busy = false
    @State private var msg: String?
    @GestureState private var gDrag = CGSize.zero
    @GestureState private var gMag: CGFloat = 1
    @GestureState private var gRot: Angle = .zero
    private let side = UIScreen.main.bounds.width - 32

    private func norm(_ a: Double) -> Double {
        var r = a.truncatingRemainder(dividingBy: 360)
        if r < 0 { r += 360 }
        return r
    }

    private func save() {
        guard let s = src else { return }
        let z = zoom, r = rot, x = ox, y = oy, t = text, rs = res
        busy = true
        DispatchQueue.global(qos: .userInitiated).async {
            let kb = Store.add(s) { render($0, zoom: z, rot: r, ox: x, oy: y, text: t, res: rs) }
            DispatchQueue.main.async {
                busy = false
                rev += 1
                if kb >= 0 { msg = "Sticker guardado (\(kb) KB)" }
                else if kb == -1 { msg = "No se pudo bajar el GIF de 500 KB. Prueba con una resolución menor." }
                else { msg = "Error al guardar el sticker" }
            }
        }
    }

    var body: some View {
        let _ = rev
        let counts = Store.packs.map { Store.files($0).count }
        let full = counts[(src?.frames.count ?? 1) > 1 ? 1 : 0] >= 30
        ScrollView {
            VStack(spacing: 12) {
                PhotosPicker(selection: $item, matching: .images) {
                    Label("Elegir imagen o GIF", systemImage: "photo")
                }.buttonStyle(.borderedProminent)

                if let s = src {
                    let img = render(s.frames[0], zoom: zoom * gMag, rot: rot + gRot.degrees,
                                     ox: ox + gDrag.width / side, oy: oy + gDrag.height / side,
                                     text: text, res: res)
                    Image(uiImage: img).resizable().scaledToFit()
                        .frame(width: side, height: side)
                        .background(Color.gray.opacity(0.2))
                        .overlay(Rectangle().stroke(Color.red, lineWidth: crop ? 3 : 0))
                        .gesture(
                            DragGesture()
                                .updating($gDrag) { v, st, _ in st = v.translation }
                                .onEnded { v in ox += v.translation.width / side; oy += v.translation.height / side },
                            including: crop ? .all : .none)
                        .simultaneousGesture(
                            MagnificationGesture()
                                .updating($gMag) { v, st, _ in st = v }
                                .onEnded { v in zoom = min(max(zoom * v, 0.2), 5) },
                            including: crop ? .all : .none)
                        .simultaneousGesture(
                            RotationGesture()
                                .updating($gRot) { v, st, _ in st = v }
                                .onEnded { v in rot = norm(rot + v.degrees) },
                            including: crop ? .all : .none)
                    HStack {
                        Button(crop ? "Listo" : "✂ Recortar") { crop.toggle() }.buttonStyle(.borderedProminent)
                        Button("Reiniciar") { zoom = 1; rot = 0; ox = 0; oy = 0 }.buttonStyle(.bordered)
                    }
                    if crop { Text("Arrastra con un dedo para mover; pellizca para acercar o girar. Lo que queda dentro del cuadro es el sticker.").font(.footnote) }
                    if s.frames.count > 1 { Text("GIF animado: \(s.frames.count) fotogramas").font(.footnote) }
                }

                Text("Zoom").frame(maxWidth: .infinity, alignment: .leading)
                Slider(value: $zoom, in: 0.3...3)
                Text("Rotación").frame(maxWidth: .infinity, alignment: .leading)
                Slider(value: $rot, in: 0...360)
                TextField("Texto (opcional)", text: $text).textFieldStyle(.roundedBorder)
                Picker("Resolución", selection: $res) {
                    ForEach([256, 384, 512], id: \.self) { Text("\($0) px").tag($0) }
                }.pickerStyle(.segmented)

                Button { save() } label: {
                    Text(busy ? "Procesando..." : (full ? "Este pack ya tiene 30 stickers" : "Guardar sticker"))
                }.buttonStyle(.borderedProminent).disabled(src == nil || busy || full)

                Text("Estáticos: \(counts[0])/30 · Animados: \(counts[1])/30").font(.footnote)
                ForEach(Array(Store.packs.enumerated()), id: \.offset) { entry in
                    let p = entry.element
                    Button("Agregar «\(p.name)» a WhatsApp") {
                        if !Store.sendToWhatsApp(p) { msg = "No se pudo abrir WhatsApp. ¿Está instalado y el pack tiene 3 o más stickers?" }
                    }.buttonStyle(.bordered).disabled(counts[entry.offset] < 3)
                }
                Text("Cada pack necesita al menos 3 stickers. Los GIFs van a su propio pack porque WhatsApp no permite mezclar animados con estáticos.").font(.footnote)
            }.padding(16)
        }
        .onChange(of: item) { newItem in
            Task {
                guard let d = try? await newItem?.loadTransferable(type: Data.self) else { return }
                if let s = Store.loadSource(d) {
                    src = s; zoom = 1; rot = 0; ox = 0; oy = 0; crop = false
                } else { msg = "No se pudo abrir la imagen" }
            }
        }
        .alert("Aviso", isPresented: Binding(get: { msg != nil }, set: { _ in msg = nil }),
               actions: { Button("OK", role: .cancel) {} },
               message: { Text(msg ?? "") })
    }
}

struct Thumb: View {
    let url: URL
    var body: some View {
        if let d = try? Data(contentsOf: url),
           let img = SDImageWebPCoder.shared.decodedImage(with: d, options: nil) {
            Image(uiImage: img.images?.first ?? img).resizable().scaledToFit()
                .background(Color.gray.opacity(0.2))
        } else {
            Color.gray.opacity(0.2).aspectRatio(1, contentMode: .fit)
        }
    }
}

struct LibraryView: View {
    @Binding var rev: Int
    @State private var tick = 0
    var body: some View {
        let _ = rev
        let _ = tick
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(Store.packs) { p in
                    let fs = Store.files(p)
                    Text("\(p.name) (\(fs.count)/30)").font(.headline)
                    if fs.isEmpty { Text("Todavía no hay stickers.") }
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3)) {
                        ForEach(fs, id: \.self) { f in
                            VStack {
                                Thumb(url: f)
                                Button("🗑 Eliminar") {
                                    try? FileManager.default.removeItem(at: f)
                                    tick += 1; rev += 1
                                }.font(.footnote)
                            }
                        }
                    }
                    Divider()
                }
                Text("Si eliminas o agregas stickers, vuelve a tocar «Agregar a WhatsApp» en la pestaña Crear para actualizar el pack.").font(.footnote)
            }.padding(16)
        }
    }
}
