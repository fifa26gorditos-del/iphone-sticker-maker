import UIKit
import ImageIO
import SDWebImage
import SDWebImageWebPCoder

struct Source { let frames: [UIImage]; let step: Double }
struct Pack: Identifiable { let id: String; let name: String; let animated: Bool }

/// Dibuja la imagen con zoom/rotación/desplazamiento/texto y la deja en 512x512 con fondo transparente.
func render(_ src: UIImage, zoom: CGFloat, rot: Double, ox: CGFloat, oy: CGFloat, text: String, res: Int) -> UIImage {
    let r = CGFloat(res)
    let fmt = UIGraphicsImageRendererFormat()
    fmt.scale = 1; fmt.opaque = false
    let base = UIGraphicsImageRenderer(size: CGSize(width: r, height: r), format: fmt).image { ctx in
        let c = ctx.cgContext
        c.saveGState()
        let s = min(r / src.size.width, r / src.size.height) * zoom
        c.translateBy(x: r / 2 + ox * r, y: r / 2 + oy * r)
        c.rotate(by: CGFloat(rot) * .pi / 180)
        c.scaleBy(x: s, y: s)
        src.draw(in: CGRect(x: -src.size.width / 2, y: -src.size.height / 2, width: src.size.width, height: src.size.height))
        c.restoreGState()
        if !text.trimmingCharacters(in: .whitespaces).isEmpty {
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: r * 0.14),
                .foregroundColor: UIColor.white, .strokeColor: UIColor.black, .strokeWidth: -6
            ]
            let str = NSAttributedString(string: text, attributes: attrs)
            let sz = str.size()
            str.draw(at: CGPoint(x: (r - sz.width) / 2, y: r * 0.92 - sz.height))
        }
    }
    let f2 = UIGraphicsImageRendererFormat()
    f2.scale = 1; f2.opaque = false
    return UIGraphicsImageRenderer(size: CGSize(width: 512, height: 512), format: f2).image { _ in
        base.draw(in: CGRect(x: 0, y: 0, width: 512, height: 512))
    }
}

enum Store {
    static let packs = [
        Pack(id: "mis_stickers", name: "Mis stickers", animated: false),
        Pack(id: "mis_stickers_animados", name: "Mis stickers animados", animated: true)
    ]

    static func dir(_ p: Pack) -> URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(p.id)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    static func files(_ p: Pack) -> [URL] {
        let all = (try? FileManager.default.contentsOfDirectory(at: dir(p), includingPropertiesForKeys: nil)) ?? []
        return all.filter { $0.lastPathComponent.hasPrefix("sticker_") }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    // MARK: cargar imagen / GIF
    static func loadSource(_ data: Data) -> Source? {
        guard let cg = CGImageSourceCreateWithData(data as CFData, nil) else { return nil }
        let n = CGImageSourceGetCount(cg)
        func thumb(_ i: Int, _ maxPx: Int) -> UIImage? {
            let o: [CFString: Any] = [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: maxPx
            ]
            guard let img = CGImageSourceCreateThumbnailAtIndex(cg, i, o as CFDictionary) else { return nil }
            return UIImage(cgImage: img)
        }
        if n <= 1 { return thumb(0, 1500).map { Source(frames: [$0], step: 0) } }
        var delays: [Double] = []
        for i in 0..<n {
            let p = CGImageSourceCopyPropertiesAtIndex(cg, i, nil) as? [CFString: Any]
            let g = p?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            var d = (g?[kCGImagePropertyGIFUnclampedDelayTime] as? Double)
                ?? (g?[kCGImagePropertyGIFDelayTime] as? Double) ?? 0.1
            if d < 0.02 { d = 0.1 }
            delays.append(d)
        }
        let total = min(delays.reduce(0, +), 10)
        let step = max(0.1, total / 60)
        var out: [UIImage] = []
        var t = 0.0
        while t < total {
            var acc = 0.0
            var idx = n - 1
            for (i, d) in delays.enumerated() { acc += d; if t < acc { idx = i; break } }
            if let im = thumb(idx, 512) { out.append(im) }
            t += step
        }
        return out.isEmpty ? nil : Source(frames: out, step: step)
    }

    // MARK: codificar WebP
    static func webp(_ img: UIImage, _ q: CGFloat) -> Data? {
        SDImageWebPCoder.shared.encodedData(with: img, format: .webP, options: [.encodeCompressionQuality: q])
    }

    static func encodeStatic(_ img: UIImage) -> Data? {
        var q: CGFloat = 0.95
        var last: Data?
        while q > 0.05 {
            last = webp(img, q)
            if let d = last, d.count <= 100_000 { return d }
            q -= 0.1
        }
        return last
    }

    static func encodeAnim(_ s: Source, _ make: (UIImage) -> UIImage) -> Data? {
        var frames = s.frames
        var dur = s.step
        while true {
            for q in [CGFloat(0.6), 0.4, 0.2] {
                let imgs = frames.map { SDImageFrame(image: make($0), duration: dur) }
                if let a = SDImageCoderHelper.animatedImage(with: imgs),
                   let d = SDImageWebPCoder.shared.encodedData(with: a, format: .webP, options: [.encodeCompressionQuality: q]),
                   d.count <= 500_000 { return d }
            }
            if frames.count <= 8 { return nil }
            frames = frames.enumerated().filter { $0.offset % 2 == 0 }.map { $0.element }
            dur *= 2
        }
    }

    /// Guarda el sticker. Devuelve KB, -1 si el GIF no baja de 500 KB, -2 si falla al escribir.
    static func add(_ s: Source, make: (UIImage) -> UIImage) -> Int {
        let animated = s.frames.count > 1
        let p = packs.first { $0.animated == animated }!
        let first = make(s.frames[0])
        guard let data = animated ? encodeAnim(s, make) : encodeStatic(first) else { return -1 }
        let d = dir(p)
        let name = "sticker_\(Int(Date().timeIntervalSince1970 * 1000)).webp"
        guard (try? data.write(to: d.appendingPathComponent(name))) != nil else { return -2 }
        let f = UIGraphicsImageRendererFormat()
        f.scale = 1; f.opaque = false
        let tray = UIGraphicsImageRenderer(size: CGSize(width: 96, height: 96), format: f).image { _ in
            first.draw(in: CGRect(x: 0, y: 0, width: 96, height: 96))
        }
        try? tray.pngData()?.write(to: d.appendingPathComponent("tray.png"))
        return data.count / 1024
    }

    // MARK: pasar el pack a WhatsApp (portapapeles + enlace, como en el ejemplo oficial de WhatsApp)
    static func sendToWhatsApp(_ p: Pack) -> Bool {
        var stickers: [[String: Any]] = []
        for f in files(p) {
            guard let d = try? Data(contentsOf: f) else { continue }
            stickers.append(["image_data": d.base64EncodedString(), "emojis": ["😀"], "accessibility_text": "Sticker"])
        }
        guard stickers.count >= 3,
              let tray = try? Data(contentsOf: dir(p).appendingPathComponent("tray.png")) else { return false }
        var json: [String: Any] = [
            "identifier": p.id, "name": p.name, "publisher": "Yo",
            "tray_image": tray.base64EncodedString(),
            "ios_app_store_link": "", "android_play_store_link": "",
            "stickers": stickers
        ]
        if p.animated { json["is_animated_sticker_pack"] = true }
        guard let data = try? JSONSerialization.data(withJSONObject: json),
              let url = URL(string: "whatsapp://stickerPack"),
              UIApplication.shared.canOpenURL(url) else { return false }
        UIPasteboard.general.setItems(
            [["net.whatsapp.third-party.sticker-pack": data]],
            options: [.localOnly: true, .expirationDate: Date(timeIntervalSinceNow: 60)]
        )
        UIApplication.shared.open(url)
        return true
    }
}
